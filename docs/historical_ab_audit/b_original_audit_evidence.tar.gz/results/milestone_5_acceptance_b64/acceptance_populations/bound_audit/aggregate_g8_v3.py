#!/usr/bin/env python3
"""Read-only mixed-provenance node bound certificates and remaining obligations."""
import argparse,datetime,gzip,json,sys
from collections import Counter
from fractions import Fraction as R
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'v2'))
from frozen_reference5.model import normalize_case,selected_legs,sequences
from stream_audit import sha_file,canonical,sha_object
from aggregate_relaxation_v1.certify_relaxation import verify_stored_lp,graph_proof,relaxation_certificate,verify_freeze as verify_relaxation_freeze


def source_for(case_id):
    transition=json.loads((ROOT.parent/'evaluation_v2/transition_manifest.json').read_text())
    if case_id in transition['certified_case_records_retained']:
        path=ROOT.parent/'runs/reference'/f'{case_id}.json'
        data=json.loads(path.read_text());assert sha_file(path)==transition['record_hashes'][str(path.relative_to(ROOT.parent))]
        return data['reference'],None,dict(path=str(path.relative_to(ROOT.parent)),sha256=sha_file(path),source='original_frozen_reference',raw_certificate_replay=False)
    path=ROOT/'v2/runs'/case_id/'report.json'
    if not path.exists():return None,None,dict(source='pending_final_reference')
    data=json.loads(path.read_text())
    if data.get('status')!='completed' or data.get('replay',{}).get('status')!='fully_replayed':
        return None,None,dict(path=str(path.relative_to(ROOT.parent)),sha256=sha_file(path),source='unresolved_final_reference')
    return data['reference'],data['replay']['sequence_primary_infima'],dict(path=str(path.relative_to(ROOT.parent)),sha256=sha_file(path),source='final_streamed_reference',raw_certificate_replay=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(ROOT/'g8_current_v3.json'));args=parser.parse_args()
    verify_relaxation_freeze()
    aggregate_path=ROOT/'aggregate_relaxation_v1/certificates.json'
    aggregate=json.loads(aggregate_path.read_text())
    assert aggregate['all_requested_superset_inequalities_certified'] and aggregate['reference_optimizer_calls']==0
    aggregate_nodes={(node['case_id'],node['dominance'],node['trace_event'],node['trace_sha256']):node for node in aggregate['nodes']}
    cases=json.loads((ROOT.parent/'stage_b/cases.json').read_text());rows=[];case_summaries=[];queries={} 
    for source in cases:
        cid=source['case_id'];case=normalize_case(source);legs=selected_legs(case);ref,summary,provenance=source_for(cid)
        result=ref['result'] if ref and ref.get('all_regimes_certified') else None
        global_J=R(result['primary_infimum']) if result and result.get('primary_infimum') is not None else None
        status_counts=Counter();case_queries=set()
        for dom in (0,1):
            trace=ROOT/'production_trace_v1/runs'/cid/f'D{dom}.jsonl.gz'
            with gzip.open(trace,'rt') as f:
                for envelope in map(json.loads,f):
                    if envelope['kind']!='event':continue
                    event=envelope['event']
                    if event['kind'] not in ('region_decision','unreachable'):continue
                    prefix=tuple(map(tuple,event['prefix']));actions=tuple(map(tuple,event['actions']))
                    row=dict(case_id=cid,dominance=bool(dom),trace_event=envelope['index'],trace_sha256=sha_file(trace),
                             prefix=event['prefix'],region=event['region'],actions=event['actions'],lower_bound=event['lower_bound'],reference_provenance=provenance,
                             exact_current_frontier_empty='unknown',bound_proof_scope='sufficient conservative inequality only; no exact node-family optimization')
                    if event['kind']=='unreachable':
                        current=prefix[-1][0] if prefix else case['origin']
                        assert all((current,site) not in legs or (site,case['destination']) not in legs for site,_ in actions)
                        row.update(status='certified_empty_by_independent_reachability',exact_current_frontier_empty=True)
                    elif result and result['status']=='infeasible_within_H_ref':
                        row.update(status='certified_empty_by_global_infeasibility',exact_current_frontier_empty=True)
                    elif (cid,bool(dom),envelope['index'],row['trace_sha256']) in aggregate_nodes:
                        proof=aggregate_nodes[(cid,bool(dom),envelope['index'],row['trace_sha256'])]
                        assert proof['source_case_sha256']==sha_object(source)
                        assert canonical(proof['prefix'])==canonical(event['prefix']) and canonical(proof['actions'])==canonical(event['actions'])
                        assert R(proof['region_lower_bound'])==R(event['lower_bound'])
                        verify_stored_lp(proof['relaxation'])
                        normalized,graph=graph_proof(source)
                        expected=relaxation_certificate(normalized,graph,prefix)
                        assert canonical(expected)==canonical(proof['relaxation'])
                        assert R(event['lower_bound'])<=R(proof['relaxation']['independent_lower_bound'])
                        row.update(status='certified_by_independent_aggregate_superset_LP',reference_lower_bound=proof['relaxation']['independent_lower_bound'],
                                   bound_proof_provenance=dict(path=str(aggregate_path.relative_to(ROOT.parent)),sha256=sha_file(aggregate_path),proof_kind=proof['certificate_kind']))
                    elif global_J is not None and R(event['lower_bound'])<=global_J:
                        row.update(status='certified_by_global_infimum',reference_lower_bound=str(global_J))
                    elif summary is not None:
                        js=[R(item['primary_infimum']) for item in summary if item.get('primary_infimum') is not None
                            and len(item['sequence'])>len(prefix) and tuple(map(tuple,item['sequence'][:len(prefix)]))==prefix
                            and tuple(item['sequence'][len(prefix)]) in actions]
                        J=min(js) if js else None
                        if J is None:row.update(status='certified_empty_by_prefix_superset',exact_current_frontier_empty=True)
                        elif R(event['lower_bound'])<=J:row.update(status='certified_by_prefix_superset_infimum',reference_lower_bound=str(J))
                        else:row.update(status='inconclusive_frontier_scope_mismatch',prefix_superset_infimum=str(J))
                    else:
                        row['status']='pending_targeted_prefix_proof' if global_J is not None else 'pending_reference'
                        case_queries.add((prefix,actions))
                    status_counts[row['status']]+=1;rows.append(row)
        query_rows=[];regime_count=0
        if provenance['source']=='original_frozen_reference' and case_queries:
            for seq,remaining,current in sequences(case,legs):
                if remaining or (current,case['destination']) not in legs:continue
                if not any(len(seq)>len(prefix) and seq[:len(prefix)]==prefix and seq[len(prefix)] in actions for prefix,actions in case_queries):continue
                charges=sum(effect in ('C','CS') for _,effect in seq);service=next((effect for _,effect in seq if effect in ('S','CS')),None)
                count=len(case['charging_segments'])**(2*charges)*(2 if service else 1)*(2 if service=='CS' else 1)
                regime_count+=count
            query_rows=[dict(prefix=prefix,actions=actions) for prefix,actions in sorted(case_queries)]
        case_summaries.append(dict(case_id=cid,status_counts=dict(status_counts),reference_provenance=provenance,targeted_queries=query_rows,targeted_regime_union=regime_count))
    result=dict(schema='hiroute-g8-mixed-provenance-node-audit-v3',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                cases=case_summaries,nodes=rows,status_counts=dict(Counter(row['status'] for row in rows)),
                required_targeted_regimes_for_retained_cases=sum(r['targeted_regime_union'] for r in case_summaries),
                literal_G8_protocol_coverage='incomplete_exact_restricted_family_query_not_implemented',exact_node_constrained_REF_implemented=False,
                primary_bound_safety_complete=all(r['status'].startswith('certified') for r in rows),
                exact_node_emptiness_classification_complete=all(r['exact_current_frontier_empty']!='unknown' for r in rows),
                scope='Every visited Region/action decision plus unreachable enqueue; prefix superset comparisons are sufficient conditions, not exact current-frontier optima')
    Path(args.output).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status_counts','required_targeted_regimes_for_retained_cases','primary_bound_safety_complete','exact_node_emptiness_classification_complete')}))

if __name__=='__main__':main()
