"""Versioned certificate sink and independent, optimizer-free full-stream verifier.

Optimizer/model files are copied verbatim except one observational sink hook.
The replay imports only the frozen independent reference model and verifier.
"""
from __future__ import annotations
import gzip, hashlib, json
from fractions import Fraction as R
from pathlib import Path
from frozen_reference5.model import normalize_case, selected_legs, sequences, assignments, regime_model, replay_witness
from frozen_reference5.lp import verify_certificate, UncertifiedLP
from frozen_reference5.solver import jsonable

SCHEMA = 'hiroute-ref-certificate-stream-v2'
CERTIFICATE_KEYS = ('primary_certificate', 'strict_feasibility_certificate', 'primary_face_certificate', 'secondary_certificate', 'secondary_face_certificate')


def canonical(value):
    return json.dumps(jsonable(value), sort_keys=True, separators=(',', ':'))


def sha_object(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def sha_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class EvidenceSink:
    def __init__(self, path, source, source_manifest):
        self.path = Path(path)
        self.raw = self.path.open('xb')
        self.zipped = gzip.GzipFile(filename='', mode='wb', fileobj=self.raw, mtime=0, compresslevel=5)
        self.index = 0
        self.write(dict(kind='header', schema=SCHEMA, case_sha256=sha_object(source), source_manifest_sha256=sha_file(source_manifest)))

    def write(self, value):
        self.zipped.write((canonical(value) + '\n').encode())

    def __call__(self, evidence):
        self.write(dict(kind='regime', index=self.index, evidence=evidence))
        self.index += 1

    def close(self, result):
        self.write(dict(kind='footer', regimes_written=self.index, solver_report=result))
        self.zipped.close()
        self.raw.close()


def rational_certificate(cert):
    result = dict(cert)
    for field in ('x', 'inequality_dual', 'equality_dual'):
        if field in result:
            result[field] = tuple(R(v) for v in result[field])
    if 'objective' in result:
        result['objective'] = R(result['objective'])
    if 'phase_I_certificate' in result:
        result['phase_I_certificate'] = rational_certificate(result['phase_I_certificate'])
    return result


def require(condition, message):
    if not condition:
        raise UncertifiedLP(message)


def verify_lp(c, A, b, equalities, raw):
    cert = rational_certificate(raw)
    if cert['status'] == 'optimal':
        verify_certificate(c, A, b, equalities, cert)
        return cert
    require(cert['status'] == 'infeasible', 'Unknown LP certificate status')
    n = len(c)
    if n == 0:
        require(any(rhs < 0 for rhs in b) or any(rhs != 0 for _, rhs in equalities), 'Invalid constant infeasibility proof')
        return cert
    # Independently reconstruct exactly the Phase-I proof obligation.
    rows, rhs = list(A), list(b)
    for row, value in equalities:
        rows.extend((row, tuple(-v for v in row)))
        rhs.extend((value, -value))
    phase_A = [tuple(row) + (R(-1),) for row in rows] + [(R(0),) * n + (R(-1),)]
    phase_b = rhs + [R(0)]
    phase_c = (R(0),) * n + (R(1),)
    phase = cert['phase_I_certificate']
    require(phase['status'] == 'optimal', 'Phase-I must have an optimal certificate')
    verify_certificate(phase_c, phase_A, phase_b, (), phase)
    require(phase['objective'] > 0, 'Nonpositive Phase-I does not prove infeasibility')
    return cert


def verify_strict(A, b, n, equalities, raw):
    rows = [tuple(row) + (R(0),) for row in A]
    rhs = list(b)
    for j in range(n):
        row = [R(0)] * (n + 1)
        row[j], row[-1] = R(-1), R(1)
        rows.append(tuple(row)); rhs.append(R(0))
    rows += [(R(0),) * n + (R(-1),), (R(0),) * n + (R(1),)]
    rhs += [R(0), R(1)]
    eq = [(tuple(row) + (R(0),), value) for row, value in equalities]
    cert = verify_lp((R(0),) * n + (R(-1),), rows, rhs, eq, raw)
    require(cert['status'] == 'optimal', 'Strict face must be optimal')
    return cert


class Minimum:
    """Constant-space summary of already-certified contenders, not a solver."""
    def __init__(self):
        self.J = self.Q = self.witness = None
        self.primary_attained = self.secondary_attained = False

    def add(self, item):
        j = item['primary_infimum']
        if self.J is None or j < self.J:
            self.J, self.Q, self.witness = j, None, None
            self.primary_attained = self.secondary_attained = False
        if j != self.J or not item['primary_attained']:
            return
        self.primary_attained = True
        q = item['secondary_infimum']
        if self.Q is None or q < self.Q:
            self.Q, self.witness, self.secondary_attained = q, None, False
        if q != self.Q or not item['secondary_attained']:
            return
        self.secondary_attained = True
        witness = item['witness']
        key = lambda w: (w['H'], w['site_action_tuple'], w['charges'])
        if self.witness is None or key(witness) < key(self.witness):
            self.witness = witness

    def result(self):
        if self.J is None:
            return dict(status='infeasible_within_H_ref')
        if not self.primary_attained:
            return dict(status='primary_unattained', primary_infimum=self.J, unattained_component='J')
        if not self.secondary_attained:
            return dict(status='secondary_unattained', J=self.J, primary_infimum=self.J, secondary_infimum=self.Q, unattained_component='Q')
        return dict(status='attained_optimum', primary_infimum=self.J, secondary_infimum=self.Q, **self.witness)


def replay_regime(case, legs, sequence, assignment, evidence):
    context = dict(sequence=sequence, segments=assignment[0], schedule_branch=assignment[1], completion_branch=assignment[2])
    require(all(canonical(evidence.get(k)) == canonical(v) for k, v in context.items()), 'Sequence/regime coverage mismatch')
    A, b, objective = regime_model(case, sequence, legs, assignment)
    n = len(objective.coefficients)
    primary = verify_lp(objective.coefficients, A, b, (), evidence['primary_certificate'])
    expected_fields = {'primary_certificate'}
    contender = None
    if primary['status'] == 'infeasible':
        status = 'closed_regime_infeasible'
    else:
        expected_fields.add('strict_feasibility_certificate')
        strict = verify_strict(A, b, n, (), evidence['strict_feasibility_certificate'])
        if strict['x'][-1] == 0:
            status = 'empty_strict_regime'
        else:
            J = primary['objective'] + objective.constant
            face = [(objective.coefficients, primary['objective'])]
            expected_fields.add('primary_face_certificate')
            primary_face = verify_strict(A, b, n, face, evidence['primary_face_certificate'])
            contender = dict(primary_infimum=J, primary_attained=primary_face['x'][-1] > 0)
            if not contender['primary_attained']:
                status = 'primary_unattained'
                require(R(evidence['primary_infimum']) == J, 'Primary infimum mismatch')
            else:
                expected_fields.update(('secondary_certificate', 'secondary_face_certificate'))
                secondary = verify_lp((R(1),) * n, A, b, face, evidence['secondary_certificate'])
                require(secondary['status'] == 'optimal', 'Secondary optimum missing')
                Q = secondary['objective']
                tie = verify_strict(A, b, n, face + [((R(1),) * n, Q)], evidence['secondary_face_certificate'])
                contender.update(secondary_infimum=Q, secondary_attained=tie['x'][-1] > 0)
                if not contender['secondary_attained']:
                    status = 'secondary_unattained'
                    require(R(evidence['primary_infimum']) == J and R(evidence['secondary_infimum']) == Q, 'Unattained face value mismatch')
                else:
                    status = 'attained_optimum'
                    witness = replay_witness(case, sequence, tie['x'][:-1], legs)
                    require(witness['J'] == J and witness['Q_total'] == Q, 'Witness objective mismatch')
                    require(R(evidence['J']) == J and R(evidence['Q_total']) == Q, 'Attained evidence value mismatch')
                    contender['witness'] = witness
    require(evidence['status'] == status, 'Regime status mismatch')
    require({k for k in CERTIFICATE_KEYS if k in evidence} == expected_fields, 'Certificate field coverage mismatch')
    return status, contender


def replay_stream(path, source, source_manifest):
    """No optimizer call: reconstruct all regimes and verify every rational proof."""
    context = None
    counts = dict(sequence_count=0, terminal_sequence_count=0, regime_count=0, closed_infeasible_regime_count=0,
                  empty_strict_regime_count=0, strict_feasible_regime_count=0, certified_regime_count=0)
    minimum = Minimum(); sequence_rows = []; prefix_minima = {}
    try:
        case = normalize_case(source); legs = selected_legs(case)
        with gzip.open(path, 'rt') as stream:
            header = json.loads(next(stream))
            require(header == dict(kind='header', schema=SCHEMA, case_sha256=sha_object(source), source_manifest_sha256=sha_file(source_manifest)), 'Stream provenance mismatch')
            for sequence, remaining, current in sequences(case, legs):
                counts['sequence_count'] += 1
                record = dict(sequence=sequence, remaining_schedule=remaining, regimes=0)
                sequence_rows.append(record)
                if remaining:
                    record['rejection'] = 'unsatisfied_hard_schedule'; continue
                if (current, case['destination']) not in legs:
                    record['rejection'] = 'directed_destination_unreachable'; continue
                counts['terminal_sequence_count'] += 1
                sequence_minimum = None
                for assignment in assignments(case, sequence):
                    context = dict(sequence=sequence, assignment=assignment)
                    entry = json.loads(next(stream))
                    require(entry['kind'] == 'regime' and entry['index'] == counts['regime_count'], 'Missing or reordered regime')
                    status, contender = replay_regime(case, legs, sequence, assignment, entry['evidence'])
                    counts['regime_count'] += 1; counts['certified_regime_count'] += 1; record['regimes'] += 1
                    if status == 'closed_regime_infeasible': counts['closed_infeasible_regime_count'] += 1
                    elif status == 'empty_strict_regime': counts['empty_strict_regime_count'] += 1
                    else:
                        counts['strict_feasible_regime_count'] += 1
                        minimum.add(contender)
                        J = contender['primary_infimum']
                        sequence_minimum = J if sequence_minimum is None else min(J, sequence_minimum)
                record['primary_infimum'] = sequence_minimum
                if sequence_minimum is not None:
                    for length in range(len(sequence) + 1):
                        prefix = sequence[:length]
                        prefix_minima[prefix] = min(prefix_minima.get(prefix, sequence_minimum), sequence_minimum)
            footer = json.loads(next(stream))
            require(footer['kind'] == 'footer' and footer['regimes_written'] == counts['regime_count'], 'Missing footer or extra regimes')
            require(next(stream, None) is None, 'Unexpected trailing evidence')
            solver = footer['solver_report']
            require(solver['all_regimes_certified'] is True and solver['result']['status'] not in ('unresolved', 'invalid_input'), 'Original solve unresolved')
            require(all(solver[k] == v for k, v in counts.items()), 'Regime/sequence counts mismatch')
            original_rows = [{k: v for k, v in row.items() if k != 'primary_infimum'} for row in sequence_rows]
            require(canonical(original_rows) == canonical(solver['sequences']), 'Sequence coverage mismatch')
            require(canonical(minimum.result()) == canonical(solver['result']), 'Reconstructed lexicographic result mismatch')
        return jsonable(dict(status='fully_replayed', all_regimes_certified=True, result=minimum.result(), **counts,
                             sequence_primary_infima=sequence_rows,
                             prefix_primary_infima=[dict(prefix=k, primary_infimum=v) for k, v in sorted(prefix_minima.items())],
                             stream_sha256=sha_file(path), stream_bytes=Path(path).stat().st_size,
                             optimality_replay_invokes_optimizer=False))
    except Exception as exc:
        return jsonable(dict(status='unresolved', all_regimes_certified=False, reason=f'{type(exc).__name__}: {exc}',
                             uncertified_regime=context, **counts))
