#!/usr/bin/env python3
"""One-worker equivalence, full certificate replay and adversarial checks."""
import gzip, json, os, resource, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from stream_reference5.solver import solve_case as stream_solve
from frozen_reference5.solver import solve_case as frozen_solve, jsonable
from stream_audit import EvidenceSink, replay_stream, sha_file, canonical
MANIFEST = ROOT / 'instrumentation_freeze.json'


def verify_freeze():
    data = json.loads(MANIFEST.read_text())
    for name, digest in data['files'].items():
        assert sha_file(ROOT / name) == digest, name
    return data


def without_observational_fields(report):
    return {k:v for k,v in report.items() if k not in ('elapsed_seconds', 'regimes')}


def main():
    verify_freeze()
    population = ROOT.parent.parent / 'stage_a/sources/prior_18_positive_fixtures.json'
    cases = json.loads(population.read_text()); rows = []
    for case in cases:
        start = time.perf_counter()
        baseline = frozen_solve(case, keep_evidence=True)
        path = ROOT / 'runs' / (case['case_id'] + '.jsonl.gz')
        sink = EvidenceSink(path, case, MANIFEST)
        streamed = stream_solve(case, keep_evidence=False, evidence_sink=sink)
        sink.close(streamed)
        replay = replay_stream(path, case, MANIFEST)
        with gzip.open(path,'rt') as f:
            payloads = [x['evidence'] for x in map(json.loads, f) if x['kind']=='regime']
        same = canonical(without_observational_fields(baseline)) == canonical(without_observational_fields(streamed))
        same_certificates = canonical(payloads) == canonical(baseline['regimes'])
        row = dict(case_id=case['case_id'], same_solver_output=same, same_raw_certificates=same_certificates,
                   replay=replay, elapsed_seconds=time.perf_counter()-start)
        rows.append(row)
        print(json.dumps(dict(case_id=case['case_id'], equivalent=same, identical_certificates=same_certificates,
                              replay=replay['status'], elapsed_seconds=row['elapsed_seconds'])),flush=True)
    # Corruptions must never certify the overall answer.
    source = cases[0]
    path = ROOT / 'runs' / (source['case_id'] + '.jsonl.gz')
    with gzip.open(path,'rt') as f: pristine = list(map(json.loads,f))
    tests=[]
    for mutation in ('drop_regime', 'change_objective', 'delete_certificate', 'mark_unresolved', 'change_case_hash'):
        entries = json.loads(json.dumps(pristine))
        if mutation == 'drop_regime': del entries[1]
        elif mutation == 'change_objective':
            for entry in entries:
                if entry['kind']=='regime' and entry['evidence']['primary_certificate']['status']=='optimal':
                    entry['evidence']['primary_certificate']['objective']='999999';break
        elif mutation == 'delete_certificate': del entries[1]['evidence']['primary_certificate']
        elif mutation == 'mark_unresolved': entries[-1]['solver_report']['all_regimes_certified']=False
        elif mutation == 'change_case_hash': entries[0]['case_sha256']='0'*64
        bad=ROOT/'runs'/('adversarial_'+mutation+'.jsonl.gz')
        with gzip.open(bad,'wt') as f:
            for entry in entries: f.write(canonical(entry)+'\n')
        result=replay_stream(bad,source,MANIFEST)
        tests.append(dict(mutation=mutation,status=result['status'],reason=result.get('reason')))
    verify_freeze()
    result=dict(schema='hiroute-stream-instrumentation-validation-v2', population_sha256=sha_file(population),
                analytic_case_count=len(rows), all_equivalent=all(r['same_solver_output'] and r['same_raw_certificates'] and r['replay']['status']=='fully_replayed' for r in rows),
                all_corruptions_rejected=all(t['status']=='unresolved' for t in tests), cases=rows, adversarial_tests=tests,
                max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, workers=1)
    (ROOT/'validation_report.json').write_text(json.dumps(jsonable(result),indent=2)+'\n')
    assert result['all_equivalent'] and result['all_corruptions_rejected']

if __name__=='__main__': main()
