#!/usr/bin/env python3
"""One-worker all-node evidence collection; invokes no reference optimizer."""
import json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
cases=json.loads((ROOT.parent/'stage_b/cases.json').read_text())
for case in cases:
 start=time.perf_counter()
 process=subprocess.run([sys.executable,str(ROOT/'production_trace_v1/trace_runner.py'),'--case-id',case['case_id']],capture_output=True,text=True)
 row=dict(case_id=case['case_id'],returncode=process.returncode,elapsed_seconds=time.perf_counter()-start,stdout=process.stdout,stderr=process.stderr)
 with (ROOT/'production_trace_progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 print(json.dumps({k:v for k,v in row.items() if k not in ('stdout','stderr')}),flush=True)
