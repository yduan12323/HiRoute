#!/usr/bin/env python3
"""Append-only one-case second pass. No production solve, no altered optimizer."""
import argparse,json,resource,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from stream_reference5.solver import solve_case,jsonable
from stream_audit import EvidenceSink,replay_stream,sha_file
from hierarchy_audit import audit_hierarchy
from validate_analytic import verify_freeze


def verify_parent():
    parent=ROOT.parent.parent
    manifest=json.loads((parent/'freeze_manifest_b_c.json').read_text())
    for name,digest in manifest['files'].items():
        if sha_file(parent/name)!=digest:raise RuntimeError('Parent frozen file changed: '+name)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('case_id');parser.add_argument('--population',default='stage_b/cases.json');args=parser.parse_args()
    verify_freeze();verify_parent()
    validated=json.loads((ROOT/'validation_report.json').read_text())
    assert validated['analytic_case_count']==18 and validated['all_equivalent'] and validated['all_corruptions_rejected']
    parent=ROOT.parent.parent
    case=next(c for c in json.loads((parent/args.population).read_text()) if c['case_id']==args.case_id)
    out=ROOT/'runs'/args.case_id
    out.mkdir(exist_ok=False)
    started=time.perf_counter();report=dict(case_id=args.case_id,scope='synthetic_H_ref4_diagnostic_not_acceptance',workers=1)
    try:
        sink=EvidenceSink(out/'regimes.jsonl.gz',case,ROOT/'instrumentation_freeze.json')
        value=solve_case(case,keep_evidence=False,evidence_sink=sink)
        sink.close(value)
        report['solve']=value
        report['replay']=replay_stream(out/'regimes.jsonl.gz',case,ROOT/'instrumentation_freeze.json')
        production=parent/'runs/production'/f'{args.case_id}.json'
        if production.exists() and report['replay']['status']=='fully_replayed':
            report['hierarchy_audit']=audit_hierarchy(case,report['replay'],json.loads(production.read_text()))
        else:report['hierarchy_audit']=dict(status='pending',reason='Production evidence absent or reference unresolved')
        report['status']='completed' if report['replay']['status']=='fully_replayed' else 'unresolved'
        verify_freeze();verify_parent()
    except Exception as exc:
        report.update(status='unresolved',reason=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc())
    report['elapsed_seconds']=time.perf_counter()-started
    report['max_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    (out/'report.json').write_text(json.dumps(jsonable(report),indent=2)+'\n')
    print(json.dumps(dict(case_id=args.case_id,status=report['status'],elapsed_seconds=report['elapsed_seconds'],max_rss_kib=report['max_rss_kib'],hierarchy_status=report.get('hierarchy_audit',{}).get('status'))),flush=True)

if __name__=='__main__':main()
