"""Independent checks against recorded HIER pruning, without production imports.

Prefix+next-action REF optima relax current-frontier restrictions. Passing this
stronger test proves the desired constrained bound. Failure is inconclusive.
"""
from fractions import Fraction as R
from frozen_reference5.model import normalize_case, selected_legs, replay_witness
from frozen_reference5.solver import jsonable
from stream_audit import canonical, require


def independent_tree(sites):
    nodes={}
    def build(members, node):
        children=()
        if len(members)>1:
            mid=len(members)//2
            children=(2*node+1,2*node+2)
            build(members[:mid],children[0]);build(members[mid:],children[1])
        nodes[node]=dict(members=members,children=children)
    build(tuple(sorted(sites)),0)
    return nodes


def actions(case, members, effect, remaining):
    if effect in ('S','CS') and not remaining:return ()
    return tuple((site,effect) for site in members if site != case['destination'] and effect in case['sites'][site])


def verify_incumbent(case, witness, incumbent_key):
    stops=[e for e in witness['events'] if e['effect'] in ('C','S','CS')]
    sequence=tuple((e['site'],e['effect']) for e in stops)
    charges=tuple(R(e['departure_energy'])-R(e['arrival_energy']) for e in stops if e['effect'] in ('C','CS'))
    replay=replay_witness(case,sequence,charges)
    require(canonical(replay['lex_key'])==canonical(incumbent_key),'Independent incumbent key mismatch')
    require(canonical(sequence)==canonical(witness['pi']),'Incumbent sequence mismatch')
    require(R(witness['time'])==replay['terminal_time_s'] and R(witness['energy'])==replay['terminal_energy_kwh'],'Incumbent terminal state mismatch')
    require(R(witness['rho'])+R(witness['energy'])==replay['Q_total'],'Incumbent charge/rho mismatch')
    require(witness['state']==dict(anchor=case['destination'],remaining_schedule=0,stop_count=len(sequence)),'Incumbent semantic state mismatch')
    legs=selected_legs(case)
    time,energy,current=case['start_time_s'],case['initial_energy_kwh'],case['origin']
    def event(effect,site,t0,t1,e0,e1):
        return dict(effect=effect,site=site,arrival_time=t0,departure_time=t1,arrival_energy=e0,departure_energy=e1)
    expected=[event('initial',current,time,time,energy,energy)]
    for stop in replay['events']:
        site=stop['site']; leg=legs[current,site]
        expected.append(event('D',site,time,time+leg.time,energy,energy-leg.energy))
        expected.append(event(stop['effect'],site,stop['arrival_time_s'],stop['completion_s'],stop['arrival_kwh'],stop['departure_kwh']))
        time,energy,current=stop['completion_s'],stop['departure_kwh'],site
    if current!=case['destination']:
        leg=legs[current,case['destination']]
        expected.append(event('D',case['destination'],time,time+leg.time,energy,energy-leg.energy))
    require(canonical(expected)==canonical(witness['events']),'Incumbent event-by-event replay mismatch')
    return replay


def audit_hierarchy(source, replay_report, production_report):
    require(replay_report['status']=='fully_replayed','Full reference replay required')
    case=normalize_case(source); legs=selected_legs(case); tree=independent_tree(case['sites'])
    partition_checks=0
    for node in tree.values():
        if not node['children']:continue
        for remaining in (0,1):
            for effect in ('C','S','CS'):
                parent=actions(case,node['members'],effect,remaining)
                children=sum((actions(case,tree[c]['members'],effect,remaining) for c in node['children']),())
                require(len(children)==len(set(children)) and set(children)==set(parent),'Static child action partition failure')
                partition_checks+=1
    rows=[]
    summaries=replay_report['sequence_primary_infima']
    for variant in production_report.get('variants',[]):
        if 'pruning_audit' not in variant:continue
        for index,entry in enumerate(variant['pruning_audit']):
            row=dict(variant=variant['variant'],audit_index=index,reason=entry['reason'],prefix=entry['prefix'],actions=entry['actions'])
            try:
                prefix=tuple(map(tuple,entry['prefix']))
                remaining=case['initial_remaining_schedule']
                for _,effect in prefix:
                    if effect in ('S','CS'):remaining=0
                expected=actions(case,tree[entry['region']]['members'],entry['effect'],remaining)
                require(canonical(expected)==canonical(entry['actions']),'Recorded region action set differs from exact static set')
                feasible=[R(r['primary_infimum']) for r in summaries if r.get('primary_infimum') is not None
                          and len(r['sequence'])>len(prefix) and tuple(map(tuple,r['sequence'][:len(prefix)]))==prefix
                          and tuple(r['sequence'][len(prefix)]) in expected]
                constrained=min(feasible) if feasible else None
                row['prefix_and_next_action_ref_infimum']=constrained
                row['constraint_scope']='All original continuous plans with this prefix and next action in Region; current frontier relaxed'
                if entry['reason']=='unreachable':
                    require(constrained is None,'Unreachable prune admits an independently feasible continuation')
                    row['status']='certified_no_feasible_continuation'
                else:
                    require(entry['reason']=='strict_primary','Unknown pruning reason')
                    bound=R(entry['lower_bound']); incumbent=verify_incumbent(case,entry['incumbent_witness'],entry['incumbent_key'])
                    require(bound>incumbent['J'],'Primary-equality or better bound incorrectly pruned')
                    row.update(lower_bound=bound,incumbent_independently_replayed=True,incumbent_J=incumbent['J'],strict_primary_only=True)
                    row['status']='certified_bound' if constrained is None or bound<=constrained else 'inconclusive_frontier_scope_mismatch'
                    if constrained is None:row['bound_inequality']='lower_bound <= +infinity (independently infeasible constrained continuation)'
                    else:row['bound_inequality']=f'{bound} <= {constrained}'
            except Exception as exc:
                row.update(status='unresolved',reason_detail=f'{type(exc).__name__}: {exc}')
            rows.append(row)
    return jsonable(dict(status='certified_recorded_prunes' if all(r['status'].startswith('certified') for r in rows) else 'incomplete',
                         recorded_prunes=len(rows),static_action_partition_checks=partition_checks,rows=rows,
                         equality_prune_safety='Every recorded strict-primary prune is checked with exact >; retained equality event trace is not present',
                         dynamic_partition_trace='Not recorded; production source assertions and aggregate counters are separate evidence',
                         all_visited_region_bound_trace='Not recorded; this artifact checks every recorded prune, not every visited node',
                         scope='Synthetic bounded diagnostic only; no real-source hierarchy or holdout claim'))
