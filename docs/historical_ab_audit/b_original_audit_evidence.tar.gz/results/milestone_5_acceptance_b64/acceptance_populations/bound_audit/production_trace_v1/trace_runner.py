#!/usr/bin/env python3
"""All-node observational trace; production optimizer and bounds unchanged."""
import argparse,dataclasses,gzip,hashlib,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT.parent/'v1')]
from traced_timecut5.hierarchy import solve_hierarchical as traced
from frozen_timecut5.hierarchy import solve_hierarchical as frozen
from stream_audit import canonical,sha_file,sha_object
from frozen_reference5.solver import jsonable
from frozen_reference5.model import normalize_case
from hierarchy_audit import verify_incumbent, independent_tree, actions
from fractions import Fraction as R
MANIFEST=ROOT/'trace_freeze.json'


def verify_freeze():
    manifest=json.loads(MANIFEST.read_text())
    for name,digest in manifest['files'].items():
        assert sha_file(ROOT/name)==digest,name


def audit_trace(case,entries):
    normalized=normalize_case(case); tree=independent_tree(normalized['sites'])
    counts=dict(region_decisions=0,partitions=0,primary_equalities_retained=0,prunes=0,unreachable=0,coverage_groups=0,incumbent_replays=0)
    memo=set();group=None;queued={};decided=set();covered=set()
    for entry in entries:
        kind=entry['kind']
        if kind=='group_start':
            assert group is None
            group=entry;queued={};decided=set();covered=set()
            state=entry['state'];prefix=tuple(map(tuple,entry['prefix']))
            assert state['stop_count']==len(prefix)
            assert state['anchor']==(prefix[-1][0] if prefix else normalized['origin'])
            remaining=normalized['initial_remaining_schedule']
            for _,effect in prefix:
                if effect in ('S','CS'):assert remaining==1;remaining=0
            assert state['remaining_schedule']==remaining
            expected=set(a for effect in ('C','S','CS') for a in actions(normalized,tree[0]['members'],effect,remaining))
            assert expected==set(map(tuple,entry['expected_actions']))
        else:assert group is not None
        assert canonical(entry['state'])==canonical(group['state']) and canonical(entry['prefix'])==canonical(group['prefix'])
        if entry['region'] is not None:
            node=tree[entry['region']];represented=actions(normalized,node['members'],entry['effect'],entry['state']['remaining_schedule'])
            assert canonical(node['members'])==canonical(entry['region_members'])
            assert canonical(represented)==canonical(entry['actions']) and represented
        if entry['incumbent_key'] is not None:
            key=canonical((entry['incumbent_key'],entry['incumbent_witness']))
            if key not in memo:
                verify_incumbent(normalized,entry['incumbent_witness'],entry['incumbent_key'])
                memo.add(key);counts['incumbent_replays']+=1
        identifier=(entry['region'],entry['effect'])
        if kind=='enqueue':
            assert identifier not in queued
            queued[identifier]=entry
        elif kind=='region_decision':
            assert identifier in queued and identifier not in decided
            assert R(queued[identifier]['lower_bound'])==R(entry['lower_bound'])
            decided.add(identifier);counts['region_decisions']+=1
            incumbent=R(entry['incumbent_key'][0]) if entry['incumbent_key'] is not None else None
            bound=R(entry['lower_bound'])
            assert entry['primary_equality']==(incumbent is not None and bound==incumbent)
            expected_decision='prune' if incumbent is not None and bound>incumbent else 'retain_split' if tree[entry['region']]['children'] else 'retain_expand'
            assert entry['decision']==expected_decision
            if entry['decision']=='prune':
                assert not covered.intersection(represented);covered.update(represented);counts['prunes']+=1
            if entry['primary_equality']:
                assert entry['decision']!='prune';counts['primary_equalities_retained']+=1
        elif kind=='partition':
            assert identifier in decided
            expected_children=tree[entry['region']]['children'];children=entry['children']
            assert tuple(child['region'] for child in children)==expected_children
            child_actions=[]
            for child in children:
                assert canonical(child['members'])==canonical(tree[child['region']]['members'])
                correct=actions(normalized,tree[child['region']]['members'],entry['effect'],entry['state']['remaining_schedule'])
                assert canonical(child['actions'])==canonical(correct)
                child_actions.extend(correct)
            assert len(child_actions)==len(set(child_actions)) and set(child_actions)==set(represented)
            counts['partitions']+=1
        elif kind=='unreachable':
            assert entry['lower_bound'] is None
            assert not covered.intersection(represented);covered.update(represented);counts['unreachable']+=1
        elif kind=='leaf_attempt':
            action=tuple(entry['action']);assert action in represented and action not in covered
            covered.add(action)
        elif kind=='group_end':
            assert set(queued)==decided
            assert covered==set(map(tuple,group['expected_actions']))==set(map(tuple,entry['covered_actions']))
            group=None;counts['coverage_groups']+=1
    assert group is None
    return counts


def run(case,dominance,path,compare=True):
    events=[]
    baseline=frozen(case,dominance) if compare else None
    result=traced(case,dominance,audit_sink=lambda event:events.append(jsonable(event)))
    equivalent=canonical(dataclasses.asdict(baseline))==canonical(dataclasses.asdict(result)) if compare else None
    counts=audit_trace(case,events)
    assert counts['region_decisions']==result.region_nodes
    assert counts['partitions']+result.pruned_regions+result.leaf_actions==result.region_nodes
    assert counts['primary_equalities_retained']==result.equality_nodes_retained
    assert counts['coverage_groups']==result.coverage_groups
    assert counts['prunes']==result.pruned_regions
    if compare:assert equivalent
    with path.open('xb') as raw:
        with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as stream:
            def write(row):stream.write((canonical(row)+'\n').encode())
            write(dict(kind='header',case_id=case['case_id'],case_sha256=sha_object(case),dominance=dominance,source_manifest_sha256=sha_file(MANIFEST)))
            for index,event in enumerate(events):write(dict(kind='event',index=index,event=event))
            write(dict(kind='footer',result=result.canonical(),metrics=jsonable(dataclasses.asdict(result)),event_count=len(events)))
    return dict(case_id=case['case_id'],dominance=dominance,complete_output_equivalence=equivalent,trace_audit=counts,
                trace_sha256=sha_file(path),events=len(events),result=result.canonical())


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--validate',action='store_true');ap.add_argument('--case-id');args=ap.parse_args();verify_freeze()
    if args.validate:
        cases=json.loads((ROOT.parent.parent/'stage_a/sources/prior_18_positive_fixtures.json').read_text());rows=[]
        for case in cases:
            for dom in (False,True):
                row=run(case,dom,ROOT/'runs'/f"{case['case_id']}_D{int(dom)}.jsonl.gz")
                rows.append(row);print(json.dumps(dict(case_id=case['case_id'],dominance=dom,equivalent=row['complete_output_equivalence'],events=row['events'])),flush=True)
        report=dict(analytic_cases=len(cases),variant_runs=len(rows),all_equivalent=all(r['complete_output_equivalence'] for r in rows),rows=rows)
        (ROOT/'validation_report.json').write_text(json.dumps(jsonable(report),indent=2)+'\n')
    else:
        validation=json.loads((ROOT/'validation_report.json').read_text());assert validation['all_equivalent'] and validation['analytic_cases']==18
        case=next(c for c in json.loads((ROOT.parent.parent/'stage_b/cases.json').read_text()) if c['case_id']==args.case_id)
        out=ROOT/'runs'/case['case_id'];out.mkdir(exist_ok=False)
        rows=[run(case,dom,out/f'D{int(dom)}.jsonl.gz') for dom in (False,True)]
        (out/'report.json').write_text(json.dumps(jsonable(rows),indent=2)+'\n')
    verify_freeze()

if __name__=='__main__':main()
