#!/usr/bin/env python3
"""Independent line-route aggregate relaxation, with constructed exact duals.

No reference optimizer or production code is invoked. This supplies sufficient
superset inequalities, not exact inherited-mask node-optimum computations.
"""
import ast,copy,datetime,json,sys
from fractions import Fraction as R
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'v2'))
from frozen_reference5.model import normalize_case,selected_legs
from frozen_reference5.lp import verify_certificate,UncertifiedLP
from frozen_reference5.solver import jsonable
from stream_audit import canonical,sha_file,sha_object


def check(condition,message):
    if not condition:raise ValueError(message)


def verify_freeze():
    manifest=json.loads((ROOT/'freeze_manifest.json').read_text())
    for name,digest in manifest['files'].items():check(sha_file(ROOT/name)==digest,'Frozen relaxation source changed: '+name)
    check(sha_file(ROOT.parent/'v2/instrumentation_freeze.json')==manifest['reference_checker_freeze_sha256'],'Reference checker freeze changed')
    checker_manifest=json.loads((ROOT.parent/'v2/instrumentation_freeze.json').read_text())
    for name,digest in checker_manifest['files'].items():check(sha_file(ROOT.parent/'v2'/name)==digest,'Frozen independent checker/model changed')
    return manifest


def graph_proof(raw):
    case=normalize_case(raw)
    check(case['schedule'] is None and case['initial_remaining_schedule']==0,'Additive charging proof is restricted to schedule-absent cases')
    eligible={effect for effects in case['sites'].values() for effect in effects if effect not in ('S','CS')}
    check(eligible<= {'C'},'Unexpected dynamically eligible semantic effect')
    # Exact edge potentials certify every path, not just sampled routes.
    potentials={case['origin']:(R(0),R(0))}
    vertices={case['origin'],case['destination'],*case['sites']}
    for edge in case['edges']:vertices.update((edge['source'],edge['target']))
    for _ in range(len(vertices)):
        changed=False
        for edge in case['edges']:
            a,b=edge['source'],edge['target']
            if a not in potentials:continue
            t,e=potentials[a]
            next_value=(t+edge['time_s'],e+edge['length_m']*case['consumption_kwh_per_m'])
            if b in potentials:check(potentials[b]==next_value,'Graph admits inconsistent time/energy path potentials')
            else:potentials[b]=next_value;changed=True
        if not changed:break
    check(set(potentials)==vertices,'Unresolved/unreachable graph vertices prevent whole-graph potential certificate')
    edges=[]
    for edge in case['edges']:
        a,b=edge['source'],edge['target'];dt=potentials[b][0]-potentials[a][0];de=potentials[b][1]-potentials[a][1]
        check(dt==edge['time_s'] and de==edge['length_m']*case['consumption_kwh_per_m'],'Edge potential identity failed')
        edges.append(dict(edge_id=edge['id'],source=a,target=b,time=dt,energy=de))
    legs=selected_legs(case);leg_checks=[]
    for (a,b),leg in sorted(legs.items()):
        check(leg.time==potentials[b][0]-potentials[a][0] and leg.energy==potentials[b][1]-potentials[a][1],'Independent selected leg violates telescoping totals')
        leg_checks.append(dict(source=a,target=b,time=leg.time,energy=leg.energy,nodes=leg.nodes,edges=leg.edges))
    drive_time,road_energy=potentials[case['destination']]
    check((case['origin'],case['destination']) in legs,'No complete physical route')
    minimum_slope=min(segment[2] for segment in case['charging_segments'])
    check(minimum_slope>0,'Charging primitive not strictly increasing')
    return case,dict(origin_potential=(R(0),R(0)),potentials=potentials,edge_checks=edges,independent_selected_leg_checks=leg_checks,
                     total_drive_time=drive_time,total_road_energy=road_energy,minimum_charging_slope=minimum_slope,
                     charging_segment_slopes=tuple(segment[2] for segment in case['charging_segments']),
                     proof='Every edge and selected leg equals the difference of exact vertex potentials. Any physically reachable sequence, including repeated self legs, telescopes from origin to destination.')


def relaxation_certificate(case,graph,prefix):
    Hmin=R(len(prefix)+1)
    delta=graph['total_road_energy']+case['reserve_kwh']-case['initial_energy_kwh']
    Qmin=max(R(0),delta);slope=graph['minimum_charging_slope'];stop=case['overhead_s']+case['lambda_stop_s']
    # Variables are real H, total Q and total charging duration D; all other
    # original restrictions (including strict q, energy masks and integrality)
    # are dropped. Every physical node plan still maps into this polyhedron.
    c=(stop,R(0),R(1))
    A=[(R(-1),R(0),R(0)),(R(0),R(-1),R(0)),(R(0),R(-1),R(0)),(R(0),slope,R(-1))]
    b=[-Hmin,R(0),-delta,R(0)]
    x=(Hmin,Qmin,slope*Qmin)
    y=(-stop,-slope if delta<=0 else R(0),-slope if delta>0 else R(0),R(-1))
    certificate=dict(status='optimal',x=x,objective=stop*Hmin+slope*Qmin,inequality_dual=y,equality_dual=())
    verify_certificate(c,A,b,(),certificate)
    return dict(variable_order=('H_relaxed','Q_total','charging_duration'),objective_coefficients=c,
                objective_constant=graph['total_drive_time'],A=A,b=b,equalities=(),certificate=certificate,
                H_min=Hmin,Q_min=Qmin,minimum_charging_slope=slope,
                independent_lower_bound=graph['total_drive_time']+certificate['objective'],
                original_node_attainment='not inferred',original_primary_secondary_status='not changed',
                exact_restricted_family_REF_implemented=False,
                strictness='Each strict q_i>0 implies Q>=0. Replacing strict charge positivity by weak inequalities enlarges the domain; relaxation attainment is not original-node attainment.')


def verify_stored_lp(lp):
    c=tuple(map(R,lp['objective_coefficients']));A=[tuple(map(R,row)) for row in lp['A']];b=list(map(R,lp['b']))
    cert=lp['certificate'];cert={**cert,'x':tuple(map(R,cert['x'])),'objective':R(cert['objective']),
                               'inequality_dual':tuple(map(R,cert['inequality_dual'])),'equality_dual':tuple(map(R,cert['equality_dual']))}
    verify_certificate(c,A,b,(),cert)
    check(R(lp['objective_constant'])+cert['objective']==R(lp['independent_lower_bound']),'Aggregate objective constant mismatch')


def main():
    manifest=verify_freeze();targets=json.loads((ROOT/'target_nodes.json').read_text())
    population=ROOT.parent.parent/'stage_b/cases.json'
    check(sha_file(population)==manifest['population_sha256'],'Frozen B population changed')
    cases={row['case_id']:row for row in json.loads(population.read_text())};graphs={};nodes=[]
    for target in targets:
        cid=target['case_id'];trace=ROOT.parent.parent/target['trace_path']
        check(sha_file(trace)==target['trace_sha256'],'Target trace changed')
        if cid not in graphs:
            normalized,proof=graph_proof(cases[cid]);graphs[cid]=(normalized,proof)
        case,graph=graphs[cid];event=target['event'];prefix=tuple(map(tuple,event['prefix']))
        check(event['kind']=='region_decision' and event['actions'],'Expected a nonempty Region/action decision')
        check(all(effect=='C' for _,effect in prefix) and all(effect=='C' for _,effect in event['actions']),'Relaxation target must take at least one more C action')
        check(event['state']['stop_count']==len(prefix) and event['state']['remaining_schedule']==0,'Trace prefix semantic state inconsistent')
        lp=relaxation_certificate(case,graph,prefix)
        check(R(event['lower_bound'])<=lp['independent_lower_bound'],'Requested bound does not pass aggregate relaxation')
        serialized=jsonable(lp);verify_stored_lp(serialized)
        nodes.append(dict(case_id=cid,dominance=target['dominance'],trace_event=target['trace_event'],trace_sha256=target['trace_sha256'],
                          prefix=event['prefix'],actions=event['actions'],region_lower_bound=event['lower_bound'],relaxation=lp,
                          certificate_kind='sufficient_independent_aggregate_superset_inequality',
                          subset_chain='exact inherited-mask node plans subset of original physical plans with the prefix and one further C stop; their (H,Q,D) projections lie in this closed linear relaxation',
                          inequality=f"{event['lower_bound']} <= {lp['independent_lower_bound']} <= infimum(exact node primary objective)",
                          source_case_sha256=sha_object(cases[cid]),exact_node_emptiness='not inferred',node_primary_secondary_status='not inferred'))
    # Check that the verifier detects damaged proof objects without a solver.
    corruptions=[]
    for mutation in ('wrong_objective','wrong_dual','infeasible_primal'):
        lp=json.loads(canonical(nodes[0]['relaxation']))
        if mutation=='wrong_objective':lp['certificate']['objective']=str(R(lp['certificate']['objective'])-1)
        elif mutation=='wrong_dual':lp['certificate']['inequality_dual'][-1]='0'
        else:lp['certificate']['x'][0]=str(R(lp['certificate']['x'][0])-1)
        try:verify_stored_lp(lp);rejected=False;reason=None
        except Exception as exc:rejected=True;reason=f'{type(exc).__name__}: {exc}'
        check(rejected,'Corrupted certificate accepted');corruptions.append(dict(mutation=mutation,rejected=rejected,reason=reason))
    # An added positive-time directed cycle cannot have the required potentials.
    bad=copy.deepcopy(cases[targets[0]['case_id']]);bad['edges'].append(dict(source=bad['destination'],target=bad['origin'],time_s=1,length_m=1,edge_id='adversarial-cycle'))
    try:graph_proof(bad);rejected=False;reason=None
    except Exception as exc:rejected=True;reason=f'{type(exc).__name__}: {exc}'
    check(rejected,'Inconsistent graph potentials accepted');corruptions.append(dict(mutation='inconsistent_positive_cycle',rejected=rejected,reason=reason))
    report=dict(schema='hiroute-aggregate-line-relaxation-v1',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                freeze_sha256=sha_file(ROOT/'freeze_manifest.json'),node_count=len(nodes),case_count=len(graphs),
                all_requested_superset_inequalities_certified=True,reference_optimizer_calls=0,
                graph_certificates={cid:proof for cid,(_,proof) in graphs.items()},nodes=nodes,adversarial_checks=corruptions,
                exact_inherited_mask_REF_implemented=False,literal_G8_protocol_coverage='separate and still incomplete',
                note='Sufficient mathematical inequality certificates do not change any original infeasible, attained, primary-open or secondary-open status.')
    (ROOT/'certificates.json').write_text(json.dumps(jsonable(report),indent=2)+'\n')
    verify_freeze();print(json.dumps(dict(nodes=len(nodes),cases=len(graphs),all_certified=True,reference_optimizer_calls=0)))

if __name__=='__main__':main()
