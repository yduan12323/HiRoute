"""Independent inventory check of retained REF producer and cold-check receipts."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(sys.argv[1]); LEDGER=Path(sys.argv[2])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
rows={r['case_id']:r for r in json.loads(LEDGER.read_text())['rows'] if r['missing_final_result_authority']}
assert len(rows)==29
verified=[]
for cid,row in sorted(rows.items()):
    stream=(ROOT/'runs_stream'/cid).exists();out=ROOT/('runs_stream' if stream else 'runs')/cid
    assert out.is_dir(),cid
    producer=json.loads((out/'producer_receipt.json').read_text());check=json.loads((out/'cold_check_receipt.json').read_text())
    proof=out/('regimes.jsonl.gz' if stream else 'full_ref_envelope.json.gz')
    assert cid==producer['case_id']==check['case_id']
    assert sha(proof)==producer['proof_sha256']==check['proof_sha256']
    assert producer['source_case_object_sha256']==check['source_case_object_sha256']==row['source_case_object_sha256']
    assert producer['source_case_file_sha256']==row['source_case_file_sha256']
    for name,digest in producer['source_py_sha256'].items():
        assert sha(ROOT/'validation/reference5'/name)==digest,(cid,name)
    assert check['cold_exact_lp_certificates_checked'] is True and check['optimizer_calls']==0
    assert check['checked_regimes']==producer['regime_count']==row['reported_finite_regimes']
    result=check['result'];assert result==producer['result']
    if 'key' in row:
        assert [result['J'],result['Q_total'],result['H'],result['site_action_tuple']]==row['key'],cid
    else:
        key=row['key_or_infimum'];assert result['status']==key['status'],cid
        for field in ('J','Q_total','H','site_action_tuple','primary_infimum','secondary_infimum'):
            if field in key:assert result[field]==key[field],(cid,field)
    verified.append({'case_id':cid,'streamed':stream,'regimes':check['checked_regimes'],'status':result['status'],
      'producer_receipt_sha256':sha(out/'producer_receipt.json'),'cold_check_receipt_sha256':sha(out/'cold_check_receipt.json'),
      'proof_sha256':sha(proof),'source_case_object_sha256':row['source_case_object_sha256']})
summary={'cases':len(verified),'regimes':sum(x['regimes'] for x in verified),'A':sum(x['case_id'].startswith(('A','S','SUP_A')) for x in verified),'B':sum(x['case_id'].startswith('B') for x in verified)}
print(json.dumps({'summary':summary,'rows':verified},sort_keys=True,indent=2))
