#!/usr/bin/env bash
set -euo pipefail
cd /home/dy/HiRoute/ref_recovery_20261011_728e720
for cid in A18_capacity_tight A18_capacity_overflow_infeasible S06_three_charges S04_C_then_CS; do
  test ! -e "runs/${cid}/producer_receipt.json"
  (
    ulimit -v 2097152
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "start_${cid}.txt"
    set +e
    /usr/bin/timeout --signal=TERM --kill-after=5s 180s /home/dy/miniconda3/envs/hiroute/bin/python produce_one.py "$cid" > "producer_${cid}.stdout" 2> "producer_${cid}.stderr"
    rc=$?
    set -e
    printf '%s\n' "$rc" > "exit_${cid}.txt"
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "end_${cid}.txt"
  ) &
  printf '%s %s\n' "$cid" "$!" >> lane_pids_batch2.txt
done
wait
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > all_done_batch2.txt
