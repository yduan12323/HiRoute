"""Isolated streaming REF certificate producer; source solver kernel is byte-copied."""
import gzip, hashlib, json, resource, sys, time
from pathlib import Path
from validation.reference5 import stream_solver_v1 as solver

ROOT=Path(__file__).resolve().parent
TARGETS={'B20','B26','B28','B36'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main(cid):
    assert cid in TARGETS
    source=ROOT/('b_cases.json' if cid.startswith('B') else 'physical_cases_h4.json')
    case=next(c for c in json.loads(source.read_text()) if c['case_id']==cid)
    case_sha=hashlib.sha256(json.dumps(case,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    out=ROOT/'runs_stream'/cid
    out.mkdir(parents=True,exist_ok=False)
    start=time.monotonic()
    proof=out/'regimes.jsonl.gz'
    with gzip.open(proof,'wt',encoding='utf-8',compresslevel=6) as stream:
        def sink(e):
            stream.write(json.dumps(solver.jsonable(e),sort_keys=True,separators=(',',':'))+'\n')
        solver.EVIDENCE_SINK=sink
        envelope=solver.solve_case(case,keep_evidence=True)
    assert envelope['result']['status']!='unresolved'
    assert envelope['regime_count']==envelope['certified_regime_count']
    assert envelope['regimes']==[]
    meta=out/'envelope.json';meta.write_text(json.dumps(solver.jsonable(envelope),sort_keys=True,separators=(',',':'))+'\n')
    receipt={'case_id':cid,'source_case_file_sha256':sha(source),'source_case_object_sha256':case_sha,
      'source_py_sha256':{f.name:sha(f) for f in sorted((ROOT/'validation/reference5').glob('*.py'))},
      'producer_sha256':sha(Path(__file__)),'proof_sha256':sha(proof),'metadata_sha256':sha(meta),
      'regime_count':envelope['regime_count'],'result':solver.jsonable(envelope['result']),
      'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
      'producer_exit':'success'}
    (out/'producer_receipt.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ('case_id','regime_count','elapsed_seconds','peak_rss_bytes','result')}),flush=True)
if __name__=='__main__':main(sys.argv[1])
