#!/usr/bin/env bash
set -euo pipefail
cd /home/dy/HiRoute/ref_recovery_20261011_728e720
for cid in SUP_A06_physical_quotient_intersection SUP_A08_physical_schedule_switch; do
  test ! -e "runs/${cid}/producer_receipt.json"
  (
    ulimit -v 2097152
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "start_${cid}_supp_v4.txt"
    set +e
    /usr/bin/timeout --signal=TERM --kill-after=5s 180s /home/dy/miniconda3/envs/hiroute/bin/python produce_one_v4.py "$cid" > "producer_${cid}_supp_v4.stdout" 2> "producer_${cid}_supp_v4.stderr"
    rc=$?
    set -e
    printf '%s\n' "$rc" > "exit_${cid}_supp_v4.txt"
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "end_${cid}_supp_v4.txt"
  ) &
  printf '%s %s\n' "$cid" "$!" >> lane_pids_supp_v4.txt
done
wait
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > all_done_supp_v4.txt
