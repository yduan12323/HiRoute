"""Create a byte inventory and lossless evidence archive from a completed tool snapshot."""
import hashlib,json,sys,tarfile
from pathlib import Path
root=Path(sys.argv[1]);target=Path(sys.argv[2]);manifest=root/'EVIDENCE_MANIFEST.json'
assert not manifest.exists() and not target.exists()
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
entries=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest.write_text(json.dumps({'schema':'hiroute_ref_recovery_29_manifest_v1','files':entries},indent=2,sort_keys=True)+'\n')
with tarfile.open(target,'w:gz') as tar:
    for p in files+[manifest]:tar.add(p,arcname=str(p.relative_to(root)))
print(json.dumps({'files':len(entries),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'archive_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'archive_bytes':target.stat().st_size}))
