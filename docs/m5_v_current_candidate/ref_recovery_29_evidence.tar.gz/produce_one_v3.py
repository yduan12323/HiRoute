import gzip, hashlib, json, resource, sys, time
from pathlib import Path

from validation.reference5.solver import jsonable, solve_case

ROOT = Path(__file__).resolve().parent
TARGETS = {
    'S01_service_deadline_equality', 'A01_one_charging_segment',
    'A13_primary_positive_charge_infimum', 'A17_energy_floor_tight',
    'A13_secondary_positive_charge_infimum', 'S02_C_then_S',
    'S03_S_then_C', 'A19_two_charge_redistribution',
    'A18_capacity_tight', 'A18_capacity_overflow_infeasible',
    'S06_three_charges', 'S04_C_then_CS',
    'S05_CS_then_C', 'A02_exactly_one_charging_breakpoint',
    'SUP_A06_physical_quotient_intersection', 'SUP_A08_physical_schedule_switch',
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main(cid):
    assert cid in TARGETS
    source = ROOT / 'physical_cases_h4.json'
    cases = json.loads(source.read_text())
    case = next(c for c in cases if c['case_id'] == cid)
    case_sha = hashlib.sha256(json.dumps(case, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    out = ROOT / 'runs' / cid
    out.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    envelope = solve_case(case, keep_evidence=True)
    assert envelope['result']['status'] != 'unresolved'
    assert envelope['regime_count'] == envelope['certified_regime_count'] == len(envelope['regimes'])
    proof = out / 'full_ref_envelope.json.gz'
    with gzip.open(proof, 'wt', encoding='utf-8', compresslevel=6) as stream:
        json.dump(jsonable(envelope), stream, sort_keys=True, separators=(',', ':'))
    receipt = {
        'case_id': cid, 'source_case_file_sha256': sha(source), 'source_case_object_sha256': case_sha,
        'source_py_sha256': {f.name: sha(f) for f in sorted((ROOT/'validation/reference5').glob('*.py'))},
        'proof_sha256': sha(proof), 'regime_count': envelope['regime_count'],
        'result': jsonable(envelope['result']), 'elapsed_seconds': time.monotonic()-start,
        'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'producer_exit': 'success',
    }
    (out/'producer_receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2)+'\n')
    print(json.dumps({k: receipt[k] for k in ('case_id','regime_count','elapsed_seconds','peak_rss_bytes','result')}), flush=True)

if __name__ == '__main__':
    main(sys.argv[1])
