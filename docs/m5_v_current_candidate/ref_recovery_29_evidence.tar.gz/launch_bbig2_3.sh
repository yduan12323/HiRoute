#!/usr/bin/env bash
set -euo pipefail
cd /home/dy/HiRoute/ref_recovery_20261011_728e720
for cid in B40 B56 B64; do
  test ! -e "runs_stream/${cid}/producer_receipt.json"
  (
    ulimit -v 2097152
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "start_${cid}_bbig2_3.txt"
    set +e
    limit=900; if [[ "$cid" == SUP_A14_unique_physical_interior ]]; then limit=1800; fi
    /usr/bin/timeout --signal=TERM --kill-after=5s "${limit}s" /home/dy/miniconda3/envs/hiroute/bin/python produce_stream_v5.py "$cid" > "producer_${cid}_bbig2_3.stdout" 2> "producer_${cid}_bbig2_3.stderr"
    rc=$?
    set -e
    printf '%s\n' "$rc" > "exit_${cid}_bbig2_3.txt"
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "end_${cid}_bbig2_3.txt"
  ) &
  printf '%s %s\n' "$cid" "$!" >> lane_pids_bbig2_3.txt
done
wait
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > all_done_bbig2_3.txt
