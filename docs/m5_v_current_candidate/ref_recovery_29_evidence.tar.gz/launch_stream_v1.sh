#!/usr/bin/env bash
set -euo pipefail
cd /home/dy/HiRoute/ref_recovery_20261011_728e720
for cid in A03_multiple_charging_breakpoints B18; do
  test ! -e "runs_stream/${cid}/producer_receipt.json"
  (
    ulimit -v 2097152
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "start_${cid}_stream_v1.txt"
    set +e
    /usr/bin/timeout --signal=TERM --kill-after=5s 180s /home/dy/miniconda3/envs/hiroute/bin/python produce_stream_v1.py "$cid" > "producer_${cid}_stream_v1.stdout" 2> "producer_${cid}_stream_v1.stderr"
    rc=$?
    set -e
    printf '%s\n' "$rc" > "exit_${cid}_stream_v1.txt"
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "end_${cid}_stream_v1.txt"
  ) &
  printf '%s %s\n' "$cid" "$!" >> lane_pids_stream_v1.txt
done
wait
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > all_done_stream_v1.txt
