#!/usr/bin/env bash
set -euo pipefail
cd /home/dy/HiRoute/ref_recovery_20261011_728e720
for cid in A13_secondary_positive_charge_infimum S02_C_then_S S03_S_then_C A19_two_charge_redistribution; do
  (
    ulimit -v 2097152
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "start_${cid}.txt"
    set +e
    /usr/bin/timeout --signal=TERM --kill-after=5s 180s /home/dy/miniconda3/envs/hiroute/bin/python produce_one.py "$cid" > "producer_${cid}.stdout" 2> "producer_${cid}.stderr"
    rc=$?
    set -e
    printf '%s\n' "$rc" > "exit_${cid}.txt"
    printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "end_${cid}.txt"
  ) &
  printf '%s %s\n' "$cid" "$!" >> lane_pids.txt
done
wait
printf '%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > all_done.txt
