import hashlib,json,resource,signal,sys,time
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from timecut5 import hierarchy,pwa,probe
from timecut5.bounded import Problem
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('180s cap')));signal.alarm(180)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
files=['physical_cases_h4.json','physical_supplement.json','physical_merge_supplement.json','b_cases.json']
cases=sum((json.loads((ROOT/n).read_text()) for n in files),[])
assert len(cases)==92
rows=[];counts=Counter();cid=None

def checked_reduce(inputs):
 inputs=tuple(inputs);outputs=pwa.reduce_frontier(inputs);counts['calls']+=1;counts['input_pieces']+=len(inputs);counts['output_pieces']+=len(outputs)
 cells=pwa._arrangement(inputs);checks=[]
 for cell in cells:
  energy=pwa._point(cell);before=[p.at(energy) for p in inputs if p.domain.contains(energy)];after=[p.at(energy) for p in outputs if p.domain.contains(energy)]
  mapping=[]
  for cut in before:
   witness=next((i for i,w in enumerate(after) if probe.dominates(w,cut)),None)
   assert witness is not None,(cid,energy,cut)
   mapping.append(witness);counts['input_cut_mappings']+=1
  checks.append({'energy':str(energy),'input_to_output':mapping,'input_count':len(before),'output_count':len(after)})
  counts['arrangement_cells']+=1
 rows.append({'case_id':cid,'call':counts['calls'],'input_pieces':len(inputs),'output_pieces':len(outputs),'cells':checks})
 assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<2*1024**3
 return outputs
for case in cases:
 cid=case['case_id'];problem=Problem(case);root=hierarchy.build_regions(problem.sites)
 checked=hierarchy._solve_hierarchical_problem(problem,True,root,reducer=checked_reduce)
 normal=hierarchy.solve_hierarchical(case,dominance=True)
 assert checked.canonical()==normal.canonical(),cid
 counts['cases']+=1
receipt={'schema':'hiroute-current-ab92-dominance-cells-v1','source_commit':'d51367ca5a8a109d3a76c35ebbc55ac4edc361bf','source_sha256':{p.name:sha(p) for p in sorted((ROOT/'src/timecut5').glob('*.py'))},'input_sha256':{n:sha(ROOT/n) for n in files},'counts':dict(counts),'rows':rows,'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'status':'passed'}
(ROOT/'current_ab_dominance_receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({k:receipt[k] for k in ('counts','elapsed_seconds','peak_rss_bytes','status')}))
