import gzip,hashlib,json,resource,signal,sys,time
from pathlib import Path
from fractions import Fraction as R
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from timecut5 import hierarchy,invocation_trace as trace,provenance
from timecut5.bounded import solve_bounded,replay_witness
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('180s cap')));signal.alarm(180)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['physical_cases_h4.json','physical_supplement.json','physical_merge_supplement.json']
cases=sum((json.loads((ROOT/n).read_text()) for n in files),[])
final=json.loads((ROOT/'FINAL_STAGE_A_RESULTS.json').read_text());expected={r['case_id']:r for r in final['case_rows']}
assert len(cases)==len(expected)==28
current=None
orig_emit,orig_start_layer,orig_start_run=trace.emit,trace.start_layer,trace.start_run

def emit(kind,**payload):
 global current
 value=json.loads(provenance.encoded(dict(seq=len(current['events']),kind=kind,payload=payload)))
 current['events'].append(value)
 return value['seq']
def start_layer(depth,layer):
 ids=[]
 for group in layer:
  i=current['next_group'];current['next_group']+=1;ids.append(i)
  emit('group_start',group_id=i,depth=depth,prefix=group[0].pi,state=[group[0].state.anchor,group[0].state.remaining_schedule,group[0].state.stop_count],
       frontier=[(p.domain.lo,p.domain.hi,p.domain.left_closed,p.domain.right_closed,p.slope,p.intercept,p.chi,p.rho,p.pi) for p in group])
 return ids
def start_run(problem,dominance,root,incumbent):
 def region(node):return dict(id=node.identifier,members=list(node.members),children=[region(c) for c in node.children])
 emit('run_start',source_case_sha256=hashlib.sha256(provenance.encoded(problem.case).encode()).hexdigest(),dominance=dominance,H_ref=problem.bound,regions=region(root))
trace.emit,trace.start_layer,trace.start_run=emit,start_layer,start_run
start=time.monotonic();rows=[];kinds={}
for c in cases:
 cid=c['case_id'];saved=expected[cid];prior=saved['key_or_infimum']
 for dom in (False,True):
  current={'events':[],'next_group':0};out=hierarchy.solve_hierarchical(c,dominance=dom);got=out.bounded.canonical()['result']
  assert got['status']==prior['status']==saved['status'],(cid,dom)
  for field,v in prior.items():
   if field=='status':continue
   if field=='site_action_tuple':assert tuple(map(tuple,got[field]))==tuple(map(tuple,v)),(cid,dom,field)
   elif field=='H':assert got[field]==v,(cid,dom,field)
   else:assert R(got[field])==R(v),(cid,dom,field)
  assert out.missing_actions==out.duplicate_actions==0
  if out.bounded.result.witness is not None:assert replay_witness(c,out.bounded.result.witness)==out.bounded.result.key
  p=ROOT/'current_a_traces'/cid/f'D{int(dom)}.jsonl.gz';p.parent.mkdir(parents=True,exist_ok=True)
  with gzip.open(p,'wt',encoding='utf8') as f:
   for e in current['events']:f.write(json.dumps(e,sort_keys=True,separators=(',',':'))+'\n')
  local={}
  for e in current['events']:
   k=e['kind'];local[k]=local.get(k,0)+1;kinds[k]=kinds.get(k,0)+1
  rows.append(dict(case_id=cid,dominance=dom,trace_sha256=sha(p),events=len(current['events']),kinds=local,
    status=got['status'],result=got,region_nodes=out.region_nodes,prunes=out.pruned_regions,
    coverage_groups=out.coverage_groups,missing_actions=out.missing_actions,duplicate_actions=out.duplicate_actions,
    witness_replayed=out.bounded.result.witness is not None))
  assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<2*1024**3
receipt={'schema':'hiroute-current-a28-hier-observational-trace-v1','source_commit':'d51367ca5a8a109d3a76c35ebbc55ac4edc361bf','source_sha256':{p.name:sha(p) for p in sorted((ROOT/'src/timecut5').glob('*.py'))},'input_sha256':{n:sha(ROOT/n) for n in files},'historical_result_sha256':sha(ROOT/'FINAL_STAGE_A_RESULTS.json'),'case_count':28,'variant_traces':len(rows),'rows':rows,'event_kind_counts':kinds,'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'status':'passed'}
(ROOT/'current_a_trace_receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True,default=str)+'\n')
print(json.dumps({k:receipt[k] for k in ('case_count','variant_traces','event_kind_counts','elapsed_seconds','peak_rss_bytes','status')}))
