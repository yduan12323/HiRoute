import hashlib,json,resource,signal,sys,time
from pathlib import Path
from fractions import Fraction as R
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
from validation.reference5.solver import solve_case
from validation.reference5.model import replay_witness
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('180s cap')));signal.alarm(180)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
assert sha(ROOT/'original_76_hand_cases.json')=='5e8f4b92bdbefdf5f35104b9430bbc2d0541517e0df41b4ecdb9ca67f85a5744'
case=json.loads((ROOT/'original_76_hand_cases.json').read_text())[0]
old=next(c for c in json.loads((ROOT/'physical_cases_h4.json').read_text()) if c['case_id']==case['case_id']);assert case==old
result=solve_case(case,keep_evidence=False);r=result['result'];expected=case['independent_expected'];key=(R(44950),R(76),3,(('4r:node/2','C'),('4r:node/3','C'),('4r:node/4','S')))
assert result['all_regimes_certified'] and result['regime_count']==result['certified_regime_count']==11072
assert r['status']=='attained_optimum' and r['lex_key']==key
w=replay_witness(case,expected['site_action_tuple'],expected['one_valid_charge_vector']);assert w['lex_key']==key
assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<2*1024**3
out={'schema':'hiroute-current-76-ref-targeted-v1','source_commit':'d51367ca5a8a109d3a76c35ebbc55ac4edc361bf','reference_source_sha256':{p.name:sha(p) for p in sorted((ROOT/'validation/reference5').glob('*.py'))},'input_sha256':sha(ROOT/'original_76_hand_cases.json'),'same_as_a15_input':True,'status':r['status'],'lex_key':str(r['lex_key']),'sequence_count':result['sequence_count'],'terminal_sequence_count':result['terminal_sequence_count'],'regime_count':result['regime_count'],'certified_regime_count':result['certified_regime_count'],'independent_witness_replayed':True,'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'result':'passed'}
(ROOT/'current_76_ref_receipt.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({k:out[k] for k in ('regime_count','elapsed_seconds','peak_rss_bytes','result')}))
