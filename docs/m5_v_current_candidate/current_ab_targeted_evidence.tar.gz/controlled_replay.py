import hashlib,json,subprocess,sys,time
from pathlib import Path
R=Path(__file__).resolve().parent
scripts=['run_current_a.py','run_current_b.py','record_current_a.py','record_current_b.py','check_current_a.py','check_current_b.py','check_current_dominance.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
steps=[]
for name in scripts:
 cmd=[sys.executable,'-B',str(R/name)];start=time.monotonic()
 try:
  proc=subprocess.run(cmd,cwd=R,capture_output=True,text=True,timeout=180)
  code=proc.returncode;timed_out=False;stdout=proc.stdout;stderr=proc.stderr
 except subprocess.TimeoutExpired as exc:
  code=None;timed_out=True;stdout=(exc.stdout or b'').decode() if isinstance(exc.stdout,bytes) else exc.stdout or '';stderr=(exc.stderr or b'').decode() if isinstance(exc.stderr,bytes) else exc.stderr or ''
 row={'script':name,'command':cmd,'script_sha256':sha(R/name),'elapsed_seconds':time.monotonic()-start,'returncode':code,'timed_out':timed_out,'stdout':stdout,'stderr':stderr};steps.append(row);print(name,code,row['elapsed_seconds'],flush=True)
 if code!=0:break
outputs=['current_a28_receipt.json','current_b64_receipt.json','current_a_trace_receipt.json','current_b_trace_receipt.json','current_a_bound_receipt.json','current_b_bound_receipt.json','current_ab_dominance_receipt.json']
receipt={'schema':'hiroute-current-ab-controlled-execution-v1','source_commit':'d51367ca5a8a109d3a76c35ebbc55ac4edc361bf','source_sha256':{str(p.relative_to(R)):sha(p) for p in sorted((R/'src/timecut5').glob('*.py'))},'input_sha256':{n:sha(R/n) for n in ['physical_cases_h4.json','physical_supplement.json','physical_merge_supplement.json','FINAL_STAGE_A_RESULTS.json','b_cases.json','B64_RESULTS.json']},'steps':steps,'outputs_sha256':{n:sha(R/n) for n in outputs if (R/n).exists()},'status':'passed' if len(steps)==len(scripts) and all(x['returncode']==0 and not x['timed_out'] for x in steps) else 'failed'}
(R/'controlled_execution.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(receipt['status'],flush=True)
if receipt['status']!='passed':raise SystemExit(1)
