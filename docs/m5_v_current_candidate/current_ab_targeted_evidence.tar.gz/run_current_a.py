import hashlib,json,resource,signal,sys,time
from fractions import Fraction as R
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from timecut5.bounded import solve_bounded,replay_witness
from timecut5.hierarchy import solve_hierarchical
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('180s cap')))
signal.alarm(180)
start=time.monotonic()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['physical_cases_h4.json','physical_supplement.json','physical_merge_supplement.json']
cases=sum((json.loads((ROOT/n).read_text()) for n in files),[])
final=json.loads((ROOT/'FINAL_STAGE_A_RESULTS.json').read_text());expected={r['case_id']:r for r in final['case_rows']}
assert len(cases)==len(expected)==28 and {c['case_id'] for c in cases}==set(expected)
rows=[]
for c in cases:
 cid=c['case_id'];saved=expected[cid];prior=saved['key_or_infimum']
 for mode in ('flat_d0','flat_d1','hier_d0','hier_d1'):
  dom=mode.endswith('d1');r=solve_hierarchical(c,dominance=dom).bounded if mode.startswith('hier') else solve_bounded(c,dominance=dom)
  got=r.canonical()['result'];assert got['status']==prior['status']==saved['status'],(cid,mode,got)
  for field,v in prior.items():
   if field=='status':continue
   if field=='site_action_tuple':assert tuple(map(tuple,got[field]))==tuple(map(tuple,v)),(cid,mode,field)
   elif field=='H':assert got[field]==v,(cid,mode,field)
   else:assert R(got[field])==R(v),(cid,mode,field)
  if r.result.witness is not None:assert replay_witness(c,r.result.witness)==r.result.key
  rows.append({'case_id':cid,'mode':mode,'source_case_sha256':hashlib.sha256(json.dumps(c,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'status':got['status'],'result':str(got),'witness_replayed':r.result.witness is not None})
 assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < 2*1024**3
receipt={'schema':'hiroute-current-a28-four-mode-targeted-v1','source_commit':'d51367ca5a8a109d3a76c35ebbc55ac4edc361bf','source_sha256':{p.name:sha(p) for p in sorted((ROOT/'src/timecut5').glob('*.py'))},'input_sha256':{n:sha(ROOT/n) for n in files},'historical_result_sha256':sha(ROOT/'FINAL_STAGE_A_RESULTS.json'),'case_count':28,'mode_rows':len(rows),'rows':rows,'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'status':'passed'}
(ROOT/'current_a28_receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({k:receipt[k] for k in ('case_count','mode_rows','elapsed_seconds','peak_rss_bytes','status')}))
