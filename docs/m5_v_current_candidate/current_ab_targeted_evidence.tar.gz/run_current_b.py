import hashlib,json,resource,signal,sys,time
from fractions import Fraction as R
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
from timecut5.bounded import solve_bounded,replay_witness
from timecut5.hierarchy import solve_hierarchical
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('180s cap')));signal.alarm(180)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
cases=json.loads((ROOT/'b_cases.json').read_text());old=json.loads((ROOT/'B64_RESULTS.json').read_text());expected={r['case_id']:r for r in old['cases']}
assert len(cases)==len(expected)==64
rows=[]
for c in cases:
 cid=c['case_id'];saved=expected[cid]
 for mode in ('flat_d0','flat_d1','hier_d0','hier_d1'):
  dom=mode.endswith('d1');r=solve_hierarchical(c,dominance=dom).bounded if mode.startswith('hier') else solve_bounded(c,dominance=dom)
  got=r.canonical()['result'];assert got['status']==saved['status'],(cid,mode,got)
  if saved['key'] is not None:
   assert got['status']=='attained_optimum'
   for k,v in zip(('J','Q_total','H','site_action_tuple'),saved['key']):
    if k=='site_action_tuple':assert tuple(map(tuple,got[k]))==tuple(map(tuple,v)),(cid,mode,k)
    elif k=='H':assert got[k]==v,(cid,mode,k)
    else:assert R(got[k])==R(v),(cid,mode,k)
  if r.result.witness is not None:assert replay_witness(c,r.result.witness)==r.result.key
  rows.append(dict(case_id=cid,mode=mode,source_case_sha256=hashlib.sha256(json.dumps(c,sort_keys=True,separators=(',',':')).encode()).hexdigest(),status=got['status'],result=str(got),witness_replayed=r.result.witness is not None))
 assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<2*1024**3
receipt={'schema':'hiroute-current-b64-four-mode-targeted-v1','source_commit':'d51367ca5a8a109d3a76c35ebbc55ac4edc361bf','source_sha256':{p.name:sha(p) for p in sorted((ROOT/'src/timecut5').glob('*.py'))},'input_sha256':sha(ROOT/'b_cases.json'),'historical_result_sha256':sha(ROOT/'B64_RESULTS.json'),'case_count':64,'mode_rows':len(rows),'rows':rows,'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'status':'passed'}
(ROOT/'current_b64_receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps({k:receipt[k] for k in ('case_count','mode_rows','elapsed_seconds','peak_rss_bytes','status')}))
