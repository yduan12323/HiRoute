import gzip,hashlib,json,sys
from collections import Counter,defaultdict
from fractions import Fraction as R
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'independent_model'));sys.path.insert(0,str(ROOT/'src'))
from model import normalize_case,selected_legs,sequences
from timecut5.bounded import Problem
from timecut5 import provenance
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['b_cases.json'];raw=json.loads((ROOT/'b_cases.json').read_text());cases={c['case_id']:c for c in raw}
rec=json.loads((ROOT/'current_b_trace_receipt.json').read_text());assert rec['status']=='passed' and rec['case_count']==64 and rec['variant_traces']==128
assert all(rec['source_sha256'][p.name]==sha(p) for p in (ROOT/'src/timecut5').glob('*.py'))
assert all(rec['input_sha256'][n]==sha(ROOT/n) for n in files)
certificates={};rows=[];counts=Counter();partition_count=0
for rr in rec['rows']:
 cid=rr['case_id'];c=normalize_case(cases[cid]);source=cases[cid];legs=selected_legs(c);problem=Problem(source)
 for pair,leg in legs.items():
  other=problem.legs[pair];assert (leg.time,leg.energy,leg.nodes,leg.edges)==(other.time,other.energy,other.path,other.edge_ids)
 p=ROOT/'current_b_traces'/cid/f"D{int(rr['dominance'])}.jsonl.gz";assert sha(p)==rr['trace_sha256']
 with gzip.open(p,'rt') as f:events=[json.loads(s) for s in f]
 assert len(events)==rr['events'] and [x['seq'] for x in events]==list(range(len(events)))
 assert events[0]['kind']=='run_start' and events[0]['payload']['source_case_sha256']==hashlib.sha256(provenance.encoded(source).encode()).hexdigest()
 assert events[0]['payload']['dominance']==rr['dominance']
 assert Counter(x['kind'] for x in events)==rr['kinds']
 groups={x['payload']['group_id']:x['payload'] for x in events if x['kind']=='group_start'}
 queries={x['seq']:x['payload'] for x in events if x['kind']=='query'}
 assert {i for i,q in queries.items() if q['classification']=='queued'}=={x['payload']['query_seq'] for x in events if x['kind']=='pop'}
 tree=events[0]['payload']['regions'];regions={}
 def walk(r):
  regions[r['id']]=r
  for child in r['children']:walk(child)
 walk(tree)
 def acts(region,effect,remaining):return tuple((s,effect) for s in region['members'] if s!=c['destination'] and effect in c['sites'][s] and (effect=='C' or remaining))
 bygroup=defaultdict(list)
 for x in events:
  if x['kind'] in ('query','pop','expansion_end'):bygroup[x['payload']['group_id']].append(x)
 for gid,items in bygroup.items():
  if not any(x['kind']=='expansion_end' for x in items):continue
  group=groups[gid];remaining=group['state'][1];expected={a for ef in ('C','S','CS') for a in acts(tree,ef,remaining)}
  covered=[]
  for x in items:
   if x['kind']=='query' and x['payload']['classification']=='unreachable':covered+=list(map(tuple,x['payload']['actions']))
   if x['kind']=='pop':
    q=queries[x['payload']['query_seq']]
    if x['payload']['decision'] in ('prune','leaf'):covered+=list(map(tuple,q['actions']))
    if x['payload']['decision']=='split':
     region=regions[q['region_id']];children=[a for child in region['children'] for a in acts(child,q['effect'],remaining)]
     assert len(children)==len(set(children)) and set(children)==set(map(tuple,q['actions']))
     partition_count+=1
  assert len(covered)==len(set(covered)) and set(covered)==expected
  end=next(x for x in items if x['kind']=='expansion_end');assert set(map(tuple,end['payload']['covered_actions']))==expected
 terminal=[]
 for seq,remaining,current in sequences(c,legs):
  if remaining or (current,c['destination']) not in legs:continue
  drive=energy=R(0);pos=c['origin'];prefix_drive=[]
  for site,effect in seq:
   leg=legs[pos,site];drive+=leg.time;energy+=leg.energy;prefix_drive.append(drive);pos=site
  leg=legs[pos,c['destination']];drive+=leg.time;energy+=leg.energy
  charge=max(R(0),energy+c['reserve_kwh']-c['initial_energy_kwh']);slope=min((s[2] for s in c['charging_segments']),default=R(0));D=slope*charge
  base=drive+len(seq)*(c['overhead_s']+c['lambda_stop_s']);service=next(((i,e) for i,(_,e) in enumerate(seq) if e in ('S','CS')),None)
  if service:
   i,e=service;duration=c['schedule']['D'];lb=base+(D+duration if e=='S' else max(D,duration))
   tail=drive-prefix_drive[i];absolute=c['schedule']['a']+duration-c['start_time_s']+tail+(len(seq)-i-1)*c['overhead_s']+len(seq)*c['lambda_stop_s'];lb=max(lb,absolute)
  else:lb=base+D
  terminal.append((seq,lb))
 for x in events:
  if x['kind'] not in ('query','pop'):continue
  if x['kind']=='query' and x['payload']['classification']=='unreachable':
   q=x['payload'];g=groups[q['group_id']];cur=g['state'][0];checks=[(cur,s,(cur,s) in legs,(s,c['destination']) in legs) for s,_ in q['actions']]
   assert all(not a or not b for _,_,a,b in checks)
   rows.append(dict(case_id=cid,dominance=rr['dominance'],trace_sha256=rr['trace_sha256'],event_index=x['seq'],kind='unreachable',checks=checks,status='independent_structural_empty'));counts['independent_structural_empty']+=1
  if x['kind']=='pop':
   query=queries[x['payload']['query_seq']];g=groups[query['group_id']];prefix=tuple(map(tuple,g['prefix']));actions=tuple(map(tuple,query['actions']));key=(cid,prefix,actions)
   if key not in certificates:
    matches=[(seq,lb) for seq,lb in terminal if len(seq)>len(prefix) and seq[:len(prefix)]==prefix and seq[len(prefix)] in actions]
    certificates[key]={'case_id':cid,'prefix':g['prefix'],'actions':query['actions'],'sequence_count':len(matches),'sequences':[{'sequence':[list(a) for a in seq],'lower_bound':str(lb)} for seq,lb in matches],'superset_lower_bound':str(min((lb for _,lb in matches),default=R(10)**99)) if matches else None}
   cert=certificates[key];lb=cert['superset_lower_bound'];ok=lb is None or R(query['bound'])<=R(lb)
   status='independent_sequence_bound' if ok and lb is not None else 'independent_structural_empty' if ok else 'open'
   rows.append(dict(case_id=cid,dominance=rr['dominance'],trace_sha256=rr['trace_sha256'],event_index=x['seq'],query_index=x['payload']['query_seq'],kind='pop',decision=x['payload']['decision'],bound=query['bound'],superset_lower_bound=lb,case_id_query=key[0],prefix=g['prefix'],actions=query['actions'],status=status));counts[status]+=1
 assert events[-1]['kind']=='run_end' and events[-1]['payload']['canonical']['result']==rr['result']
assert counts['open']==0,counts
assert len([r for r in rows if r['kind']=='pop'])==1407 and len([r for r in rows if r['kind']=='unreachable'])==144 and sum(counts.values())==1551,counts
out={'schema':'hiroute-current-b64-complete-bound-partition-audit-v1','source_commit':rec['source_commit'],'source_sha256':rec['source_sha256'],'input_sha256':rec['input_sha256'],'independent_model_sha256':sha(ROOT/'independent_model/model.py'),'trace_receipt_sha256':sha(ROOT/'current_b_trace_receipt.json'),'case_count':64,'variant_traces':128,'counts':dict(counts),'static_partitions_checked':partition_count,'query_certificates':list(certificates.values()),'event_rows':rows}
(ROOT/'current_b_bound_receipt.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'counts':dict(counts),'partitions':partition_count,'query_certificates':len(certificates)}))
