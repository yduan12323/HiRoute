import json, subprocess, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CASES=['A01_one_charging_segment','A13_primary_positive_charge_infimum','A17_energy_floor_tight']

for case in CASES:
    start=time.monotonic()
    with (ROOT/f'producer_{case}.stdout').open('w') as out,(ROOT/f'producer_{case}.stderr').open('w') as err:
        p=subprocess.Popen(['/opt/miniconda3/bin/python','produce_one.py',case],cwd=ROOT,stdout=out,stderr=err)
        reason='normal'
        print(json.dumps({'case_id':case,'pid':p.pid,'started':start,'deadline_seconds':180,'rss_limit_bytes':2*1024**3}),flush=True)
        while p.poll() is None:
            if time.monotonic()-start>180:reason='timeout_180_seconds';p.kill()
            if reason!='normal':break
            time.sleep(.25)
        p.wait()
    item={'case_id':case,'pid':p.pid,'returncode':p.returncode,'reason':reason,'elapsed_seconds':time.monotonic()-start,'rss_reported_in_producer_receipt':True,'stdout_path':f'producer_{case}.stdout','stderr_path':f'producer_{case}.stderr'}
    (ROOT/f'supervision_{case}.json').write_text(json.dumps(item,indent=2,sort_keys=True)+'\n')
    print(json.dumps(item),flush=True)
