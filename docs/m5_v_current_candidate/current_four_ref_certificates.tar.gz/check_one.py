"""Cold exact-rational REF envelope audit; no optimizer imports or calls."""
import gzip, hashlib, json, sys
from fractions import Fraction as R
from pathlib import Path

from validation.reference5.model import assignments, normalize_case, regime_model, replay_witness, selected_legs, sequences

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'))

def dot(a, b):
    return sum((x*y for x,y in zip(a,b)), R(0))

def optimal(cert, c, A, b, eq=()):
    assert cert['status']=='optimal'
    x=tuple(map(R, cert['x'])); y=tuple(map(R, cert['inequality_dual'])); z=tuple(map(R, cert['equality_dual']))
    n=len(c)
    assert len(x)==n and len(y)==len(A) and len(z)==len(eq)
    assert all(dot(row,x)<=rhs for row,rhs in zip(A,b))
    assert all(dot(row,x)==rhs for row,rhs in eq)
    assert all(v<=0 for v in y)
    assert all(sum((row[j]*v for row,v in zip(A,y)),R(0))+sum((row[j]*v for (row,_),v in zip(eq,z)),R(0))==c[j] for j in range(n))
    val=dot(c,x)
    assert val==dot(b,y)+dot((rhs for _,rhs in eq),z)==R(cert['objective'])
    return x,val

def certified(cert,c,A,b,eq=()):
    if cert['status']=='optimal':
        return optimal(cert,c,A,b,eq)
    assert cert['status']=='infeasible'
    if len(c)==0:
        assert cert['constant_constraints_verified']
        assert any(rhs<0 for rhs in b) or any(rhs!=0 for _,rhs in eq)
        return None,None
    rows=list(A);rhs=list(b)
    for row,value in eq:
        rows.extend((row,tuple(-v for v in row)));rhs.extend((value,-value))
    phase_A=[tuple(row)+(R(-1),) for row in rows]+[(R(0),)*len(c)+(R(-1),)]
    phase_b=rhs+[R(0)]
    phase_c=(R(0),)*len(c)+(R(1),)
    _,value=optimal(cert['phase_I_certificate'],phase_c,phase_A,phase_b)
    assert value>0
    return None,None

def strict(cert,A,b,n,eq=()):
    rows=[tuple(row)+(R(0),) for row in A];rhs=list(b)
    for j in range(n):
        row=[R(0)]*(n+1);row[j]=R(-1);row[-1]=R(1)
        rows.append(tuple(row));rhs.append(R(0))
    rows.extend(((R(0),)*n+(R(-1),),(R(0),)*n+(R(1),)));rhs.extend((R(0),R(1)))
    eql=[(tuple(row)+(R(0),),value) for row,value in eq]
    return optimal(cert,(R(0),)*n+(R(-1),),rows,rhs,eql)

def main(cid):
    out=ROOT/'runs'/cid
    receipt=json.loads((out/'producer_receipt.json').read_text())
    proof=out/'full_ref_envelope.json.gz'
    assert sha(proof)==receipt['proof_sha256']
    source=ROOT/'physical_cases_h4.json'
    assert sha(source)==receipt['source_case_file_sha256']
    assert {f.name:sha(f) for f in sorted((ROOT/'validation/reference5').glob('*.py'))}==receipt['source_py_sha256']
    case=next(c for c in json.loads(source.read_text()) if c['case_id']==cid)
    assert hashlib.sha256(canon(case).encode()).hexdigest()==receipt['source_case_object_sha256']
    with gzip.open(proof,'rt') as f: envelope=json.load(f)
    prepared=normalize_case(case);legs=selected_legs(prepared)
    terminal=[]; contexts=[]
    for sequence,remaining,current in sequences(prepared,legs):
        if remaining or (current,prepared['destination']) not in legs:continue
        for assignment in assignments(prepared,sequence):
            contexts.append((sequence,assignment))
    assert len(contexts)==len(envelope['regimes'])==envelope['regime_count']==envelope['certified_regime_count']==receipt['regime_count']
    contenders=[];counts={}
    for (sequence,assignment),e in zip(contexts,envelope['regimes']):
        assert canon(e['sequence'])==canon(sequence)
        assert canon(e['segments'])==canon(assignment[0])
        assert e['schedule_branch']==assignment[1] and e['completion_branch']==assignment[2]
        A,b,obj=regime_model(prepared,sequence,legs,assignment);n=len(obj.coefficients)
        _,primary=certified(e['primary_certificate'],obj.coefficients,A,b)
        if primary is None:
            assert e['status']=='closed_regime_infeasible';counts[e['status']]=counts.get(e['status'],0)+1;continue
        xs,slack=strict(e['strict_feasibility_certificate'],A,b,n)
        if xs[-1]==0:
            assert e['status']=='empty_strict_regime';counts[e['status']]=counts.get(e['status'],0)+1;continue
        assert xs[-1]>0
        J=primary+obj.constant
        face=[(obj.coefficients,primary)]
        xp,_=strict(e['primary_face_certificate'],A,b,n,face)
        if xp[-1]==0:
            assert e['status']=='primary_unattained' and R(e['primary_infimum'])==J
            contenders.append(('primary_unattained',J,None,None,None));counts[e['status']]=counts.get(e['status'],0)+1;continue
        qx,Q=certified(e['secondary_certificate'],(R(1),)*n,A,b,face)
        assert qx is not None
        xq,_=strict(e['secondary_face_certificate'],A,b,n,face+[((R(1),)*n,Q)])
        if xq[-1]==0:
            assert e['status']=='secondary_unattained' and R(e['primary_infimum'])==J and R(e['secondary_infimum'])==Q
            contenders.append(('secondary_unattained',J,Q,None,None));counts[e['status']]=counts.get(e['status'],0)+1;continue
        assert xq[-1]>0 and e['status']=='attained_optimum' and R(e['J'])==J and R(e['Q_total'])==Q
        witness=replay_witness(prepared,sequence,xq[:-1],legs)
        assert witness['J']==J and witness['Q_total']==Q
        contenders.append(('attained_optimum',J,Q,witness,xq[:-1]));counts[e['status']]=counts.get(e['status'],0)+1
    result=envelope['result']
    if not contenders:
        assert result['status']=='infeasible_within_H_ref'
    else:
        J=min(r[1] for r in contenders)
        primary=[r for r in contenders if r[1]==J and r[0]!='primary_unattained']
        if not primary:
            assert result['status']=='primary_unattained' and R(result['primary_infimum'])==J
        else:
            Q=min(r[2] for r in primary)
            attained=[r for r in primary if r[2]==Q and r[0]=='attained_optimum']
            if not attained:
                assert result['status']=='secondary_unattained' and R(result['J'])==J and R(result['secondary_infimum'])==Q
            else:
                winner=min(attained,key=lambda r:(r[3]['H'],r[3]['site_action_tuple'],r[3]['charges']))[3]
                assert result['status']=='attained_optimum'
                for k in ('J','Q_total','H','site_action_tuple','charges'):
                    if k=='site_action_tuple':assert canon(result[k])==canon(winner[k])
                    elif k=='H':assert result[k]==winner[k]
                    elif k=='charges':assert tuple(map(R,result[k]))==tuple(winner[k])
                    else:assert R(result[k])==winner[k]
                assert R(result['primary_infimum'])==J and R(result['secondary_infimum'])==Q
    assert canon(result)==canon(receipt['result'])
    check={'case_id':cid,'proof_sha256':sha(proof),'source_case_object_sha256':receipt['source_case_object_sha256'],
           'checked_regimes':len(contexts),'regime_status_counts':counts,'result':result,'cold_exact_lp_certificates_checked':True,
           'optimizer_calls':0,'checker_sha256':sha(Path(__file__))}
    (out/'cold_check_receipt.json').write_text(json.dumps(check,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'case_id':cid,'checked_regimes':len(contexts),'status':result['status']}),flush=True)

if __name__=='__main__': main(sys.argv[1])
